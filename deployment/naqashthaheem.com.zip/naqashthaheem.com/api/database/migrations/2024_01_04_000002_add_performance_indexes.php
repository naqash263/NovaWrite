<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Add indexes for posts table
        Schema::table('posts', function (Blueprint $table) {
            $table->index(['is_published', 'published_at'], 'posts_published_index');
            $table->index(['category_id', 'is_published'], 'posts_category_published_index');
            $table->index(['user_id', 'is_published'], 'posts_user_published_index');
            $table->index('views', 'posts_views_index');
            $table->index('created_at', 'posts_created_at_index');
            $table->index('approval_status', 'posts_approval_status_index');
        });

        // Add indexes for workflows table
        Schema::table('workflows', function (Blueprint $table) {
            $table->index(['status', 'created_at'], 'workflows_status_created_index');
            $table->index(['workflow_category_id', 'status'], 'workflows_category_status_index');
            $table->index(['created_by', 'status'], 'workflows_user_status_index');
            $table->index(['approval_status', 'status'], 'workflows_approval_status_index');
        });

        // Add indexes for users table
        Schema::table('users', function (Blueprint $table) {
            $table->index('role', 'users_role_index');
            $table->index('created_at', 'users_created_at_index');
        });

        // Add indexes for categories table
        Schema::table('categories', function (Blueprint $table) {
            $table->index('slug', 'categories_slug_index');
        });

        // Add indexes for workflow_categories table
        Schema::table('workflow_categories', function (Blueprint $table) {
            $table->index('slug', 'workflow_categories_slug_index');
        });
    }

    public function down()
    {
        Schema::table('posts', function (Blueprint $table) {
            $table->dropIndex('posts_published_index');
            $table->dropIndex('posts_category_published_index');
            $table->dropIndex('posts_user_published_index');
            $table->dropIndex('posts_views_index');
            $table->dropIndex('posts_created_at_index');
            $table->dropIndex('posts_approval_status_index');
        });

        Schema::table('workflows', function (Blueprint $table) {
            $table->dropIndex('workflows_status_created_index');
            $table->dropIndex('workflows_category_status_index');
            $table->dropIndex('workflows_user_status_index');
            $table->dropIndex('workflows_approval_status_index');
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex('users_role_index');
            $table->dropIndex('users_created_at_index');
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->dropIndex('categories_slug_index');
        });

        Schema::table('workflow_categories', function (Blueprint $table) {
            $table->dropIndex('workflow_categories_slug_index');
        });
    }
};