<?php $__env->startComponent('mail::message'); ?>
# Reset Your Password

Hello <?php echo e($user->name); ?>,

You requested to reset your password for your NovaWrite account. Click the button below to reset your password:

<?php $__env->startComponent('mail::button', ['url' => $resetUrl]); ?>
Reset Password
<?php echo $__env->renderComponent(); ?>

**Important:** This reset link will expire in <?php echo e($expiresIn); ?> for security reasons.

If the button above doesn't work, you can copy and paste the following link into your browser:

<?php echo e($resetUrl); ?>


If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.

Thanks,<br>
<?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?><?php /**PATH /Users/naqashthaheem/NovaWrite/backend/resources/views/emails/password-reset.blade.php ENDPATH**/ ?>