<?php if (isset($component)) { $__componentOriginalaa758e6a82983efcbf593f765e026bd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa758e6a82983efcbf593f765e026bd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php if($type === 'new'): ?>
# New Workflow Available: <?php echo e($workflow->title); ?> 📝
<?php elseif($type === 'updated'): ?>
# Workflow Updated: <?php echo e($workflow->title); ?> 🔄
<?php elseif($type === 'approved'): ?>
# Workflow Approved: <?php echo e($workflow->title); ?> ✅
<?php elseif($type === 'rejected'): ?>
# Workflow Update: <?php echo e($workflow->title); ?> ❌
<?php else: ?>
# Workflow Notification: <?php echo e($workflow->title); ?> 📋
<?php endif; ?>

Hi <?php echo e($user->name); ?>,

<?php if($type === 'new'): ?>
A new workflow has been added to your account: **<?php echo e($workflow->title); ?>**. This workflow is now available for you to use in your writing projects.
<?php elseif($type === 'updated'): ?>
The workflow **<?php echo e($workflow->title); ?>** has been updated with new content and improvements. Check out the latest version!
<?php elseif($type === 'approved'): ?>
Great news! Your workflow **<?php echo e($workflow->title); ?>** has been approved and is now available for use.
<?php elseif($type === 'rejected'): ?>
We've reviewed your workflow **<?php echo e($workflow->title); ?>** and it requires some modifications before it can be approved.
<?php else: ?>
There's an update regarding the workflow **<?php echo e($workflow->title); ?>**.
<?php endif; ?>

## Workflow Details

**Title:** <?php echo e($workflow->title); ?>  
**Description:** <?php echo e($workflow->description ?? 'A professional writing workflow to enhance your productivity.'); ?>


## What You Can Do

- 📖 **View Workflow**: Access the complete workflow details
- 📝 **Start Using**: Begin implementing the workflow in your projects
- 💡 **Get Tips**: Learn best practices for effective writing
- 🎯 **Track Progress**: Monitor your workflow implementation

<?php if (isset($component)) { $__componentOriginal15a5e11357468b3880ae1300c3be6c4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a5e11357468b3880ae1300c3be6c4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::button'),'data' => ['url' => $workflowUrl]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mail::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($workflowUrl)]); ?>
View Workflow
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a5e11357468b3880ae1300c3be6c4f)): ?>
<?php $attributes = $__attributesOriginal15a5e11357468b3880ae1300c3be6c4f; ?>
<?php unset($__attributesOriginal15a5e11357468b3880ae1300c3be6c4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a5e11357468b3880ae1300c3be6c4f)): ?>
<?php $component = $__componentOriginal15a5e11357468b3880ae1300c3be6c4f; ?>
<?php unset($__componentOriginal15a5e11357468b3880ae1300c3be6c4f); ?>
<?php endif; ?>

## Workflow Benefits

- Streamlined writing process
- Professional templates and guides
- Step-by-step instructions
- Best practices and tips
- Improved productivity and quality

## Need Help?

If you have questions about this workflow or need assistance implementing it, our support team is ready to help.

Happy writing!

Best regards,<br>
**The NovaWrite Team**<br>
<?php echo e(config('app.name')); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $attributes = $__attributesOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $component = $__componentOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__componentOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php /**PATH /Users/naqashthaheem/NovaWrite/backend/resources/views/emails/workflow-notification.blade.php ENDPATH**/ ?>