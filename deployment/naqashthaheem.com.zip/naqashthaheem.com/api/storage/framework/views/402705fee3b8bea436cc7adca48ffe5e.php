<?php $__env->startComponent('mail::message'); ?>
# Verify Your Email Address

Hello <?php echo e($user->name); ?>,

Thank you for registering with <?php echo e(config('app.name')); ?>! To complete your registration and start using your account, please verify your email address by clicking the button below.

<?php $__env->startComponent('mail::button', ['url' => $verificationUrl]); ?>
Verify Email Address
<?php echo $__env->renderComponent(); ?>

If you didn't create an account with <?php echo e(config('app.name')); ?>, you can safely ignore this email.

**Important:** This verification link will expire in 24 hours for security reasons.

If the button above doesn't work, you can copy and paste the following link into your browser:

<?php echo e($verificationUrl); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?> Team

---

**Need help?** If you're having trouble verifying your email, please contact our support team at <?php echo e(config('mail.from.address')); ?>.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/naqashthaheem/NovaWrite/backend/resources/views/emails/email-verification.blade.php ENDPATH**/ ?>